/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java_swing;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 *
 * @author AYASHANM
 */
public class Login {
    public static void main(String[] args) {
        final JFrame frame = new JFrame("Login");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setSize(255, 150);
        
        final JPanel panel = new JPanel();
        frame.getContentPane().setLayout(new GridLayout());
        
        final JLabel usertxt = new JLabel("Username :");
        final JLabel passtxt = new JLabel("Password :");
        
        final JTextField user = new JTextField(10);
        
        final JPasswordField pass = new JPasswordField(10);
        
        JButton blogin = new JButton("Login");
        JButton bclose = new JButton("Cancel");
        
        panel.add(usertxt);
        panel.add(user);
        panel.add(passtxt);
        panel.add(pass);
        panel.add(blogin);
        panel.add(bclose);
        frame.add(panel);
        frame.setVisible(true);
        
        blogin.addActionListener (new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent arg0){
                String usr = user.getText();
                String pas = pass.getText();
                
                if(usr.equals("") && pas.equals("")){
                    JOptionPane.showMessageDialog(null, "Maaf Username/password tidak boleh kosong");
                }else{
                    if (usr.equals("admin") && pas.equals("admin")){
                        JOptionPane.showMessageDialog(null, "Berhasil login sebagai :"+usr);
                        user.setText("");
                        pass.setText("");
                        frame.setTitle("Login");
                        frame.setVisible(true);
                    }else{
                        JOptionPane.showMessageDialog(null, "Maaf User/password Anda Salah");
                        user.setText("");
                        pass.setText("");
                    }
                }
            }
        });
        
        bclose.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent arg0){
              frame.setVisible(false);
            }
        });
    }
}
